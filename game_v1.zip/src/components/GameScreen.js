/* GameScreen.js */
import React, { useState } from "react";
import "./GameScreen.css";
import StaminaGauge from "./StaminaGauge";
import backgroundImage from "../assets/background/background_office.webp";

// ゲージ表示用のコンポーネント
const Gauge = ({ label, value, max, color }) => {
	const fillWidth = `${(value / max) * 100}%`;
	return (
		<div className="gauge-container">
			<label>{label}</label>
			<div className="gauge">
				<div className="gauge-fill" style={{ width: fillWidth, backgroundColor: color }}></div>
			</div>
		</div>
	);
};

function GameScreen({ username, onSaveAndExit, savedGame }) {
	const initialPlayerState =
		savedGame && savedGame.playerState
			? savedGame.playerState
			: {
					rank: "アナリスト",
					stamina: 100,
					motivation: 3,
					stress: 0,
					workLifeBalance: 0,
					exp: {
						intellect: 0,
						mentalStrength: 0,
						communication: 0,
						focus: 0,
						creativity: 0,
						businessKnowledge: 0,
						itFundamentals: 0
					},
					coreSkills: {
						problemSolving: 0,
						facilitation: 0,
						presentation: 0,
						documentation: 0,
						research: 0
					},
					projectPromotion: {
						leadership: 0,
						projectPlanning: 0,
						projectManagement: 0,
						riskManagement: 0
					},
					knowledge: {
						industryKnowledge: 0,
						businessKnowledge: 0,
						itKnowledge: 0
					}
			  };

	const initialGameTime =
		savedGame && savedGame.gameTime
			? savedGame.gameTime
			: {
					year: 1,
					month: 4,
					week: 1
			  };

	const [player, setPlayer] = useState(initialPlayerState);
	const [year, setYear] = useState(initialGameTime.year);
	const [month, setMonth] = useState(initialGameTime.month);
	const [week, setWeek] = useState(initialGameTime.week);

	const updatePlayerState = (newState) => {
		setPlayer((prevPlayer) => ({
			...prevPlayer,
			exp: {
				...prevPlayer.exp,
				...newState.exp
			},
			...newState
		}));
	};

	const advanceWeek = () => {
		setWeek((prevWeek) => {
			if (prevWeek === 4) {
				setMonth((prevMonth) => {
					if (prevMonth === 12) {
						setYear((prevYear) => prevYear + 1);
						return 1;
					} else {
						return prevMonth + 1;
					}
				});
				return 1;
			} else {
				return prevWeek + 1;
			}
		});

		updatePlayerState({
			stamina: Math.max(0, player.stamina - 10),
			stress: Math.min(50, player.stress + 5)
		});
	};

	const handleAction = (action) => {
		if (action === "work") {
			updatePlayerState({
				stamina: Math.max(0, player.stamina - 20),
				stress: Math.min(50, player.stress + 10),
				exp: {
					intellect: (player.exp?.intellect ?? 0) + 5
				}
			});
		} else if (action === "rest") {
			updatePlayerState({
				stamina: Math.min(100, player.stamina + 30),
				stress: Math.max(0, player.stress - 10)
			});
		}
		advanceWeek();
	};

	return (
		<div className="game-screen" style={{ backgroundImage: `url(${backgroundImage})` }}>
			<header className="header">
				<h1>{username}のステータス</h1>
				<button onClick={() => onSaveAndExit(player)}>中断して保存</button>
			</header>
			<div className="main-content">
				<h2>プレイヤーステータス</h2>
				<StaminaGauge value={player.stamina} max={100} />
				<div className="status-gauges">
					<Gauge label="やる気" value={player.motivation * 20} max={100} color="#f39c12" />
					<Gauge label="ストレス" value={player.stress} max={50} color="#e74c3c" />
					<Gauge label="ワークライフバランス" value={50 + player.workLifeBalance} max={100} color="#3498db" />
				</div>
				<div className="skills">
					<h3>基礎経験値 (EXP)</h3>
					<p>知力: {player.exp?.intellect ?? 0}</p>
					<p>精神力: {player.exp?.mentalStrength ?? 0}</p>
					<p>コミュ力: {player.exp?.communication ?? 0}</p>
					<p>集中力: {player.exp?.focus ?? 0}</p>
					<p>創造力: {player.exp?.creativity ?? 0}</p>
					<p>ビジネス知識: {player.exp?.businessKnowledge ?? 0}</p>
					<p>IT基礎力: {player.exp?.itFundamentals ?? 0}</p>
				</div>
			</div>
			<footer className="footer">{/* フッターコンテンツ */}</footer>
		</div>
	);
}

export default GameScreen;
