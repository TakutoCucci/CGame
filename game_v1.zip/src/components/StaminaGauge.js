// StaminaGauge.js
import React, { useRef, useEffect } from "react";
import * as d3 from "d3";
import "./StaminaGauge.css";

const StaminaGauge = ({ value, max }) => {
	const svgRef = useRef(null);
	const width = window.innerWidth / 2; // ゲージの幅
	const height = 80; // ゲージの高さ
	const leftHeight = height * 0.3; // 左側の高さ（30%）
	const rightHeight = height; // 右側の高さ（100%）

	useEffect(() => {
		const svg = d3
			.select(svgRef.current)
			.attr("width", width)
			.attr("height", height)
			.style("position", "absolute")
			.style("bottom", "20px") // 画面下部からの距離
			.style("left", "50%")
			.style("transform", "translateX(-50%)"); // 中央揃え

		// 台形のパスデータ
		const pathData = `
            M 0,${height}
            L 0,${leftHeight}
            L ${width},${rightHeight}
            L ${width},${height}
            Z
        `;

		// SVGの内容をクリア
		svg.selectAll("*").remove();

		// 台形の背景
		svg.append("path").attr("d", pathData).attr("fill", "#3498db").attr("stroke", "#2980b9").attr("stroke-width", 2);

		// 影を追加
		svg.append("path").attr("d", pathData).attr("fill", "rgba(0, 0, 0, 0.2)").attr("stroke", "none").attr("transform", "translate(4, 4)");

		// スタミナ値に基づくフィルの描画
		const fillHeight = (value / max) * rightHeight;
		const fillPathData = `
            M 0,${height}
            L 0,${leftHeight}
            L ${width},${Math.min(fillHeight, rightHeight)}
            L ${width},${height}
            Z
        `;

		svg.append("path").attr("d", fillPathData).attr("fill", "#2ecc71").attr("stroke", "#27ae60").attr("stroke-width", 2);

		// ゲージを囲む枠線
		svg.append("path").attr("d", pathData).attr("fill", "none").attr("stroke", "#2980b9").attr("stroke-width", 2);
	}, [value, max, width, height]);

	return <svg ref={svgRef} />;
};

export default StaminaGauge;
