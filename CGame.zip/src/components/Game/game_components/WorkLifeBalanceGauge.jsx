import React, { useEffect, useRef } from "react";
import * as d3 from "d3";

// 定数の定義
const width = 600; // ゲージの幅
const height = 40; // ゲージの高さ
const radius = 10; // 角の丸み
const maxBalance = 50; // ワークライフバランスの最大値（-50～50）
const leftMargin = 100; // 左側の余白
const rightMargin = 100; // 右側の余白
const verticalPadding = 30; // 上下の余白
const tickCount = 11; // 目盛りの数

const WorkLifeBalanceGauge = ({ workLifeBalance }) => {
	const svgRef = useRef(); // svgRefをsvgRefに変更
	const gaugeClipRef = useRef();

	useEffect(() => {
		const svgHeight = height + verticalPadding * 2; // 上下の余白を含んだ全体の高さ
		const totalWidth = width + leftMargin + rightMargin; // 全体の幅

		// svgのセットアップ
		const svg = d3.select(svgRef.current).attr("width", totalWidth).attr("height", svgHeight).style("background", "transparent");

		// 全体の背景フレーム（Work、Lifeのテキストを含む）
		svg.append("rect")
			.attr("x", 0)
			.attr("y", verticalPadding - 10)
			.attr("width", totalWidth)
			.attr("height", height + 20)
			.attr("rx", radius + 5)
			.attr("ry", radius + 5)
			.attr("fill", "#6BB3FF") // 背景色（青）
			.attr("stroke", "#FFFFFF")
			.attr("stroke-width", 3);

		// 背景フレームの描画（ゲージの背景）
		svg.append("rect")
			.attr("x", leftMargin)
			.attr("y", verticalPadding)
			.attr("width", width)
			.attr("height", height)
			.attr("rx", radius)
			.attr("ry", radius)
			.attr("fill", "#E0E0E0")
			.attr("stroke", "#FFFFFF")
			.attr("stroke-width", 2);

		// ゲージの描画とクリップパスの設定
		const gauge = svg.append("rect").attr("x", leftMargin).attr("y", verticalPadding).attr("width", width).attr("height", height).attr("rx", radius).attr("ry", radius).attr("fill", "#FFD700");

		const clipPath = svg.append("defs").append("clipPath").attr("id", "balance-clip");
		clipPath
			.append("rect")
			.attr("x", leftMargin + width / 2)
			.attr("y", verticalPadding)
			.attr("height", height)
			.attr("width", 0); // 初期状態は0に設定

		gauge.attr("clip-path", "url(#balance-clip)");
		gaugeClipRef.current = svg.select("#balance-clip rect").node();

		// ゲージ内の目盛りの追加
		const ticks = d3.range(-maxBalance, maxBalance + 1, (maxBalance * 2) / (tickCount - 1));

		svg.selectAll(".tick")
			.data(ticks)
			.enter()
			.append("line")
			.attr("class", "tick")
			.attr("x1", (d) => leftMargin + width / 2 + (d / maxBalance) * (width / 2))
			.attr("y1", verticalPadding + 5) // 少し下げて目盛りを見やすく
			.attr("x2", (d) => leftMargin + width / 2 + (d / maxBalance) * (width / 2))
			.attr("y2", verticalPadding + height - 5) // 少し上げて目盛りを見やすく
			.attr("stroke", "#FFFFFF") // 目盛りの色を白に設定
			.attr("stroke-width", 2) // 目盛りの幅を太く設定
			.attr("opacity", 1); // 目盛りの透明度を100%に

		// 「Work」と「Life」のラベルを追加
		svg.append("text")
			.attr("x", leftMargin / 2)
			.attr("y", svgHeight / 2)
			.attr("dominant-baseline", "middle")
			.attr("text-anchor", "middle")
			.attr("font-size", "24px")
			.attr("font-weight", "bold")
			.attr("fill", "#FFFFFF")
			.text("Work");

		svg.append("text")
			.attr("x", totalWidth - rightMargin / 2)
			.attr("y", svgHeight / 2)
			.attr("dominant-baseline", "middle")
			.attr("text-anchor", "middle")
			.attr("font-size", "24px")
			.attr("font-weight", "bold")
			.attr("fill", "#FFFFFF")
			.text("Life");
	}, []);

	useEffect(() => {
		const balanceWidth = width / 2; // 中央から左右の幅
		const center = width / 2; // 中央位置

		// workLifeBalanceの変化に応じてクリップパスを更新（中央から左右に広がる）
		if (gaugeClipRef.current) {
			const direction = workLifeBalance >= 0 ? 1 : -1; // 右か左かの方向を決定
			const absValue = Math.abs(workLifeBalance); // 絶対値を取る

			d3.select(gaugeClipRef.current)
				.transition()
				.duration(800)
				.ease(d3.easeCubicInOut)
				.attr("x", leftMargin + center - (direction === -1 ? (absValue / maxBalance) * balanceWidth : 0)) // 塗りつぶしの始点
				.attr("width", (absValue / maxBalance) * balanceWidth); // 幅を調整
		}
	}, [workLifeBalance]);

	return <svg ref={svgRef}></svg>;
};

export default WorkLifeBalanceGauge;
